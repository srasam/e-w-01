package webapp;

public class LoginDao {

}
