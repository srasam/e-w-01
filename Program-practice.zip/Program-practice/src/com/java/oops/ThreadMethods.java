package com.java.oops;

public class ThreadMethods {
	
	public void walk() {
		System.out.println("walk 4 miles");
	}
	public void swim() {
		System.out.println("swim 10 laps");
	}
	public void exercise() {
		System.out.println("cardio- 25 jumping jacks");
	}
	

}
