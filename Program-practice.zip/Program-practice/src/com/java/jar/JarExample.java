package com.java.jar;

public class JarExample {

	public static void main(String[] args) {
		System.out.println("Hello world!");
	}

}
