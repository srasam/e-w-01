package com.java.arrays;
class Test{
    public static void main(String []args){
        System.out.println(args.length);

        for(int i=0;i<2;i++){
            System.out.println(args[i]);
        }
        
    }
}