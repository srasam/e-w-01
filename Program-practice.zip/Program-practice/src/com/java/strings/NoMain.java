package com.java.strings;

public class NoMain {
static {
	System.out.println("no main method");
}
public void test() {
	System.out.println("hello");
}

public static void main(String[] args) {
	
}
}
