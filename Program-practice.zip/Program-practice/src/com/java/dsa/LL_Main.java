package com.java.dsa;



public class LL_Main {

	public static void main(String[] args) {
		
Linked_List list= new Linked_List();
list.insert(5);
list.insert(10);
list.insert(3);
list.insert(4);

list.show();


	}

}
