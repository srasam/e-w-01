package com.java.dsa;

public class LinkedList_Node {
	
	int data;
	LinkedList_Node next;//reference

}
