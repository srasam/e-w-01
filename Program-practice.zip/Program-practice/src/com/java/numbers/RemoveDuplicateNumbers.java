package com.java.numbers;

import java.util.ArrayList;
import java.util.List;

public class RemoveDuplicateNumbers{
	
	public List<Integer> findDuplicates(List<Integer> list){
		return list;
	}
	public static void main(String args[]) {
		
	}
	

}