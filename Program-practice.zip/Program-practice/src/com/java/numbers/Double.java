package com.java.numbers;

public class Double {

	public static void main(String[] args) {
		double d1= 12.345;
		double d2= 12.345;
		System.out.println(d1==d2);
		
	}

}
