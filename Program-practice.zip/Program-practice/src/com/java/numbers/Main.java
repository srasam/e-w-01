package com.java.numbers;

public class Main{ 
    String color; 
    public static void main(String argv[]){ 
      System.out.println(someMethod());
    } 
    public static String someMethod(){ 
       return "hello"; 
    } 
  } 
