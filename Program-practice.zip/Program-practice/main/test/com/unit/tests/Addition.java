package com.unit.tests;

public class Addition {
public int add(int numA, int numB) {
	return numA+numB;
	
}
}
