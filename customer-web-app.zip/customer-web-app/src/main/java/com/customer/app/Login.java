package com.customer.app;

public class Login {
	private String customerName;
	private String customerNumber;
	
	public String getUsernmae() {
		return customerName;
	}
	public void setUsername(String customerNumber) {
		this.customerName = customerNumber;
	}
	public String getPassword() {
		return customerNumber;
	}
	public void setPassword(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	

}
