package jspdemo;

public class Table {
	private String table_name;
	
	public String getTablename() {
		return table_name;
	}

	public void setTablename(String table_name) {
		this.table_name = table_name;
	}

	public Table(String tablename) {
	
		this.table_name = tablename;
		
	}
	

}
