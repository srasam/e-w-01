package com.demo.servlet;

import javax.servlet.http.HttpServlet;

public class SessionDemo extends HttpServlet{
	

}
